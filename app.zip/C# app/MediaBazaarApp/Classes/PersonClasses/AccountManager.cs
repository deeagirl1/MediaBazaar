﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MediaBazaarApp.Classes.Person
{
    class AccountManager
    {
        private List<IAccount> accounts;
        public bool Add(IAccount account)
        {
            return false;
        }
        public bool Remove()
    }
}
